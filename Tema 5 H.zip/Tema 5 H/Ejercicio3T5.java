public class Ejercicio3T5 {
	
	public static void main (String[] args) {
		int i = 0;
		
		do {
			System.out.println(i);
				i+=5;
			}
			while(i <= 100);
	}
}

