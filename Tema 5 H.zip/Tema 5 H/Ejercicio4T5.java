public class Ejercicio4T5 {
	
	public static void main (String[] args) {
		
		for(int i = 320; i >= 160; i-=20){
			System.out.println(i);
			}
	}
}

